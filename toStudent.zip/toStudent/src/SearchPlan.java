public enum SearchPlan {
    LESS_TIME, LESS_PRICE
}
