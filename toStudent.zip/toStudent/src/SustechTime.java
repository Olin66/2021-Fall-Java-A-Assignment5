public class SustechTime {
    private int hour;
    private int minute;

    //todo: you can add any fields or methods you like
    //
    public SustechTime(String timeInfo) {
    }


    public int timeDifference(SustechTime targetTime) {
        return 0;
    }


    @Override
    public String toString() {
        return null;
    }
}
